public struct aharide {
    public private(set) var text = "Hello, World! hihi"

    public init() {
    }
}
